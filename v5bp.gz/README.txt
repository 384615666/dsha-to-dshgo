synthetic v5 fixture
